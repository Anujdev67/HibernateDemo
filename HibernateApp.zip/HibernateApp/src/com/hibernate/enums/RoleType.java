package com.hibernate.enums;

public enum RoleType {
	EXECUTIVE, ACCOUNT_HOLDER
}
