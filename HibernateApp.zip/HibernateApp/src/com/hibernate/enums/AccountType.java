package com.hibernate.enums;

public enum AccountType {
  SAVINGS,CURRENT,DEMAT
}
